module.exports= function date(){
    let d = new Date()
    return d
}